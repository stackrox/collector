## 0.6.1 (2015-04-14)

### Changes

* Begins this ChangeLog ([@tbetbetbe][])
* Updates to version 0.4 of googleauth. ([@tbetbetbe][])
* Switch the extension to use the call API. ([@tbetbetbe][])
* Refactor the C extension to avoid identifiers used by ruby ([@yugui][])

[@tbetbetbe]: https://github.com/tbetbetbe
[@yugui]: https://github.com/yugui
