# Ruby gRPC Tools

This package distributes protoc and the Ruby gRPC protoc plugin for Windows, Linux, and Mac.

Before this package is published, the following directories should be filled with the corresponding `protoc` and `grpc_ruby_plugin` executables.

 - `bin/x86-linux`
 - `bin/x86_64-linux`
 - `bin/x86-macos`
 - `bin/x86_64-macos`
 - `bin/x86-windows`
 - `bin/x86_64-windows`
